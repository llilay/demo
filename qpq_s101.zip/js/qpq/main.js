var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var HallUi101_1 = require("./game101/HallUi101");
var PlayerInfoUi_1 = require("./game101/PlayerInfoUi");
var layaMaxUI_1 = require("./ui/layaMaxUI");
var Main = /** @class */ (function (_super) {
    __extends(Main, _super);
    function Main() {
        var _this = _super.call(this) || this;
        qpq.g_qpqData = new qpq.data.QpqData();
        qpq.g_configCenter = new qpq.data.ConfigCenter();
        qpq.g_qpqData.requestWebConfig();
        gamelib.core.getPlayerData = qpq.data.PlayerData.getPlayerData;
        qpq.MainUiClass = HallUi101_1.default;
        window['qpq']['hall']['UserInfoUi'] = PlayerInfoUi_1.default;
        _this.registerClass(layaMaxUI_1.ui.qpq, "ui.qpq");
        return _this;
    }
    Main.prototype.loadGamesConfigs = function () {
        qpq.g_configCenter.init(_super.prototype.loadGamesConfigs, this);
    };
    Main.prototype.onResloaded = function () {
        this._gdm = new qpq.GameManager();
        _super.prototype.onResloaded.call(this);
    };
    Main.prototype.close = function () {
        _super.prototype.close.call(this);
        if (this._gdm['m_hall'])
            this._gdm['m_hall'].onExit();
    };
    Main.prototype.reshow = function (jsonData) {
        qpq.g_qpqData.m_reshowData = jsonData;
        if (jsonData)
            qpq.g_qpqData.m_lastGameGroupId = jsonData.groupId;
        else
            qpq.g_qpqData.m_lastGameGroupId = 0;
        _super.prototype.reshow.call(this, jsonData);
        if (this._gdm['m_hall'])
            this._gdm['m_hall'].onEnter();
    };
    return Main;
}(gamelib.core.GameMain));
//激活启动类
new Main();
var ui1;

},{"./game101/HallUi101":4,"./game101/PlayerInfoUi":5,"./ui/layaMaxUI":9}],2:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var GameList = /** @class */ (function () {
    function GameList(res) {
        this._res = res;
        this._panel = res.p_1;
        this.setData(); // 设置数据
    }
    // 显示
    GameList.prototype.show = function () {
        this._panel.visible = true;
    };
    // 隐藏
    GameList.prototype.close = function () {
        this._panel.visible = false;
    };
    // 设置数据
    GameList.prototype.setData = function () {
        this._panel.destroyChildren();
        // for (var i = 0; i < this._panel.numChildren; i) 
        // {
        // 	this._panel.getChildAt(0).removeSelf();
        // }
        this._data = [];
        this._data = qpq.g_configCenter.goldGames; // 游戏配置
        var num = Math.ceil(this._data.length / 2);
        for (var i = 0; i < this._data.length; i++) {
            console.log(this._data[i].icon);
            var scene = utils.tools.createSceneByViewObj(this._data[i].icon);
            this._panel.addChild(scene);
            var empty;
            if (scene.width > 250) {
                empty = 257 - scene.width;
            }
            else {
                empty = 0;
            }
            if (i < num) {
                scene.x = 257 * i + 10 - empty;
                scene.y = 0;
            }
            else {
                scene.x = (i - num) * 257 + 10 - empty;
                scene.y = 210;
            }
            scene.on(Laya.Event.CLICK, this, this.onClickBox, [this._data[i]]);
        }
    };
    // 点击事件
    GameList.prototype.onClickBox = function (config, evt) {
        evt.stopPropagation();
        console.log("onClickBox::" + config);
        playButtonSound();
        var gameroom = config.rooms;
        if (config.type == 1) // 功能
         {
            this.onHongBao(config);
        }
        else if (config.type == 3) {
            g_signal.dispatch('showRoom1Ui', config.enter_index);
        }
        else // 游戏
         {
            if (gameroom == undefined) {
                if (config.rule == undefined) {
                    g_childGame.enterGameByClient(config.gz_id, true);
                }
                else {
                    this.enterAutoCreateRoom(config); // 根据规则进入游戏
                }
            }
            else {
                if (gameroom.length <= 1) // 直接进入游戏
                 {
                    qpq.enterRoom(config.gz_id, config.rooms[0]);
                }
                else // 创建房间
                 {
                    g_signal.dispatch('showRoomUi', config);
                }
            }
        }
    };
    // 通过规则进入游戏
    GameList.prototype.enterAutoCreateRoom = function (config) {
        config.rule.game_id = config.game_id;
        config.rule.gz_id = config.gz_id;
        config.rule.gameName = config.name;
        // GameVar.g_platformData['room_name'] = config.room.name;
        GameVar.g_platformData['gameName'] = config.name;
        sendNetMsg(0x2013, JSON.stringify(config.rule));
        g_signal.dispatch("showQpqLoadingUi", { msg: "创建牌局中..." });
    };
    // 红包
    GameList.prototype.onHongBao = function (config) {
        g_signal.dispatch('showHongBaoui', 0);
    };
    return GameList;
}());
exports.default = GameList;

},{}],3:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.g_signInfo = null; //签到数据
/**
     * 签到
     * @function
     * @DateTime 2018-10-13T11:41:31+0800
     * @return   {boolean}                [description]
     */
function getCanSign() {
    if (this.m_signInfo == null)
        return false;
    var b = false;
    if (this.m_signInfo) {
        for (var _i = 0, _a = this.m_signInfo.list; _i < _a.length; _i++) {
            var item = _a[_i];
            if (item.statue == 1) {
                b = true;
                break;
            }
        }
    }
    return b;
}
exports.getCanSign = getCanSign;
function playGetItemEffect(msId, num) {
}
exports.playGetItemEffect = playGetItemEffect;
function enterRoom(gz_id, rd) {
    if (rd.ticket > gamelib.data.UserInfo.s_self.m_money) {
        g_uiMgr.showAlertUiByArgs({ msg: "您的游戏币,还差" + (rd.ticket - gamelib.data.UserInfo.s_self.m_money) + "才能进入房间哦!" });
        return;
    }
    if (rd.level > gamelib.data.UserInfo.s_self.m_level) {
        g_uiMgr.showAlertUiByArgs({ msg: "您的等级不足" + rd.level + "级，不能进入房间" });
        return;
    }
    if (rd.vip > gamelib.data.UserInfo.s_self.vipLevel) {
        g_uiMgr.showAlertUiByArgs({ msg: "您的VIP等级不足" + rd.vip + "级，不能进入房间" });
        return;
    }
    qpq.enterGameByRoomId(gz_id, rd.roomId);
}
exports.enterRoom = enterRoom;
function getVipInfo(level) {
    if (level == 0)
        return exports.g_vipInfoList[0];
    for (var _i = 0, g_vipInfoList_1 = exports.g_vipInfoList; _i < g_vipInfoList_1.length; _i++) {
        var temp = g_vipInfoList_1[_i];
        if (temp.index == level)
            return temp;
    }
    return null;
}
exports.getVipInfo = getVipInfo;
function getHeadBoxSkin(level) {
    if (level <= 5)
        return getGameResourceUrl("window/icom_head2.png", "qpq");
    if (level <= 10)
        return getGameResourceUrl("window/icom_head3.png", "qpq");
    if (level <= 15)
        return getGameResourceUrl("window/icom_head4.png", "qpq");
    return getGameResourceUrl("window/icom_head5.png", "qpq");
}
exports.getHeadBoxSkin = getHeadBoxSkin;
/**
 * 获得军衔名
 * @function
 * @DateTime 2018-10-11T11:21:15+0800
 * @param    {number}                 level [description]
 * @return   {string}                       [description]
 */
function getMilitaryRank(level) {
    var arr = ["平民", "列兵", "上等兵", "下士", "中士", "上士", "准尉", "少尉", "中尉", "上尉", "大尉", "少校", "中校", "上校", "大校", "少将", "中将", "上将", "大将军", "元帅", "大元帅"];
    if (level < 0)
        level = 0;
    if (level >= arr.length)
        level = arr.length - 1;
    return arr[level];
}
exports.getMilitaryRank = getMilitaryRank;
/**
 * 获得军衔资源
 * @function
 * @DateTime 2018-10-12T16:28:07+0800
 * @param    {number}                 level [description]
 * @return   {string}                       [description]
 */
function getMilitaryRankIcon(level) {
    if (level < 0)
        level = 0;
    if (level >= 21)
        level = 20;
    return getGameResourceUrl("window/icom_head2.png", "qpq");
}
exports.getMilitaryRankIcon = getMilitaryRankIcon;
// 隐藏部分号码
function getPhoneString(phone) {
    var str = phone.substr(0, 3);
    str += "****";
    str += phone.substr(7);
    return str;
}
exports.getPhoneString = getPhoneString;

},{}],4:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var SignIn_1 = require("./SignIn");
var RankUI_1 = require("./RankUI");
var Global_1 = require("./Global");
var GameList_1 = require("./GameList");
var SubHall1_1 = require("./SubHall1");
var HallUi101 = /** @class */ (function (_super) {
    __extends(HallUi101, _super);
    function HallUi101() {
        return _super.call(this, "qpq/Art_Hall.scene") || this;
    }
    // 初始化
    HallUi101.prototype.init = function () {
        _super.prototype.init.call(this);
        qpq.g_commonFuncs = new qpq.CommonFuncs();
        this._clickEventObjects.push(this._res);
        this._gameList = new GameList_1.default(this._res);
        qpq.registrerSignalHandle(qpq.SignalMsg.showSigninUi, SignIn_1.default);
        qpq.registrerSignalHandle(qpq.SignalMsg.showRankUi, RankUI_1.default);
        this.registrerBtnHandle("btn_qianDao", qpq.SignalMsg.showSigninUi);
        // this.registrerBtnHandle("btn_tuiguang",SubHall1);
        this.registrerBtnHandle("btn_rank", qpq.SignalMsg.showRankUi);
        this.registrerBtnHandle("showRoomUi", SubHall1_1.default);
    };
    // 协议
    HallUi101.prototype.reciveNetMsg = function (msgId, data) {
        _super.prototype.reciveNetMsg.call(this, msgId, data);
        switch (msgId) {
            case 0x0F1A: // 公共配置签到列表
                // g_signInfo = data;
                break;
            case 0x0F1B: // 公共配置签到
                if (data.result == 0) {
                    return;
                }
                Global_1.g_signInfo.list[data.type - 1].statue = 2;
                var arr = [];
                for (var _i = 0, _a = Global_1.g_signInfo.list[data.type - 1].awards; _i < _a.length; _i++) {
                    var aw = _a[_i];
                    arr.push({ msId: aw.msId, num: aw.num });
                }
                g_signal.dispatch('showGetItemEffect', arr);
                break;
        }
    };
    HallUi101.prototype.showCallBoard = function () {
    };
    // 发送协议
    HallUi101.prototype.onReciveNetMsg = function () {
    };
    // 玩家VIP信息
    HallUi101.prototype.updateMoney = function () {
        if (qpq.data.PlayerData.s_self) {
            this._res["txt_diamond"].text = utils.tools.getMoneyDes(qpq.data.PlayerData.s_self.m_money); // 金钱数量
        }
    };
    HallUi101.prototype.playGetItemEffect = function (msId, num) {
        // g_signal.dispatch('showGetItemEffect',[{msId:msId,num:num}]);
    };
    HallUi101.prototype.onResize = function (evt) {
        _super.prototype.onResize.call(this, evt);
    };
    // 信息
    HallUi101.prototype.onLocalSignal = function (msg, data) {
        switch (msg) {
            case "showRoomUi":
                //  g_uiMgr.openUi("qpq/Art_SubHall1.scene",SubHall1,data)
                break;
            default:
                // code...
                break;
        }
    };
    return HallUi101;
}(qpq.hall.BaseHall));
exports.default = HallUi101;

},{"./GameList":2,"./Global":3,"./RankUI":6,"./SignIn":7,"./SubHall1":8}],5:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 有签名
 * @type {[type]}
 */
var PlayerInfoUi = /** @class */ (function (_super) {
    __extends(PlayerInfoUi, _super);
    function PlayerInfoUi() {
        return _super.call(this) || this;
    }
    PlayerInfoUi.getRandomSign = function () {
        return "说点什么呢~哼哼唧唧";
    };
    PlayerInfoUi.prototype.onStageClick = function (evt) {
        console.log("PlayerInfoUi  dddddddd" + this.owner.parent);
    };
    PlayerInfoUi.prototype.init = function () {
        this._txt_input = this._res["txt_input"];
        this.addBtnToListener("btn_shop2");
        this.addBtnToListener("btn_shop");
        this.addBtnToListener("btn_modify");
        if (this._res['btn_shop2'])
            this._shop_btn = this._res['btn_shop2'];
        if (this._res['btn_shop'])
            this._shop_btn = this._res['btn_shop'];
        if (this._res['img_diamond']) {
            if (GameVar.g_platformData["gold_res_name"]) {
                this._res["img_diamond"].skin = GameVar.g_platformData["gold_res_name"];
            }
        }
        this._txt_input.maxChars = 60;
        this._txt_input.prompt = PlayerInfoUi.getRandomSign();
    };
    PlayerInfoUi.prototype.setData = function (pd) {
        this._pd = pd;
    };
    PlayerInfoUi.prototype.onClose = function () {
        _super.prototype.onClose.call(this);
    };
    PlayerInfoUi.prototype.onShow = function () {
        _super.prototype.onShow.call(this);
        var pid = 0;
        var headUrl;
        var nickname;
        var address;
        var money;
        if (this._pd != 0 && this._pd != null) {
            pid = this._pd.pid;
        }
        else {
            this._pd = null;
        }
        if (this._pd == null || pid == GameVar.pid) {
            pid = 0;
            this._res['btn_modify'].visible = true;
            if (this._shop_btn)
                this._shop_btn.visible = true;
            money = gamelib.data.UserInfo.s_self.getGold_num();
            this._txt_input.editable = true;
            this._txt_input.mouseEnabled = true;
            headUrl = GameVar.playerHeadUrl;
            nickname = GameVar.nickName;
            address = gamelib.data.UserInfo.s_self.m_address;
            sendNetMsg(0x2035, 1, pid, "");
        }
        else {
            pid = this._pd.pid;
            nickname = this._pd.name;
            headUrl = this._pd.headUrl;
            money = this._pd.value;
            address = this._pd.address;
            this._res['btn_modify'].visible = false;
            if (this._shop_btn)
                this._shop_btn.visible = false;
            this._txt_input.editable = false;
            this._txt_input.mouseEnabled = false;
            this._txt_input.text = this._pd.sign;
        }
        if (pid == 0)
            pid = GameVar.pid;
        this._res["icon_head"].skin = headUrl;
        this._res["txt_id"].text = "ID:" + pid;
        // this._res["txt_name"].text = nickname;
        utils.tools.setLabelDisplayValue(this._res["txt_name"], nickname);
        this._res["txt_money"].text = money + "";
        this._res["txt_money"].text = utils.tools.getMoneyByExchangeRate(money);
        if (this._res['txt_address'])
            this._res['txt_address'].text = address;
        if (this._res['txt_ip'])
            this._res['txt_ip'].text = "";
        this._pd = null;
    };
    PlayerInfoUi.prototype.reciveNetMsg = function (msgId, data) {
        if (msgId == 0x2035) {
            try {
                var obj = JSON.parse(data.msg);
                this._netData = obj;
                this._txt_input.text = obj["签名"];
            }
            catch (e) {
                this._txt_input.text = "";
            }
        }
    };
    PlayerInfoUi.prototype.onClickObjects = function (evt) {
        playButtonSound();
        switch (evt.currentTarget.name) {
            case "btn_shop2":
            case "btn_shop":
                g_uiMgr.openShop(2);
                this.close();
                break;
            case "btn_modify":
                if (this._txt_input.text == "") {
                    g_uiMgr.showAlertUiByArgs({ msg: getDesByLan("签名不能为空") });
                    return;
                }
                if (this._netData == null)
                    this._netData = {};
                this._netData["签名"] = this._txt_input.text;
                sendNetMsg(0x2035, 0, GameVar.pid, JSON.stringify(this._netData));
                g_uiMgr.showTip(getDesByLan("修改成功!"));
                break;
        }
    };
    return PlayerInfoUi;
}(gamelib.core.Ui_NetHandle));
exports.default = PlayerInfoUi;

},{}],6:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var RankUi = /** @class */ (function (_super) {
    __extends(RankUi, _super);
    function RankUi() {
        return _super.call(this, "qpq/Art_Rank.scene") || this;
    }
    // 初始化
    RankUi.prototype.init = function () {
        _super.prototype.init.call(this);
        this._list = this._res['list_1']; // 榜单
        this._txt_money = this._res['txt_diamond']; // 自己的金钱树
        this._self_rank_icon = this._res['img_rankicom']; // 自己的奖牌
        this._self_rank_txt = this._res['txt_rank']; // 自己的排名
        this._list.dataSource = [];
        this._list.renderHandler = Laya.Handler.create(this, this.updateItem, null, false);
        this._noticeOther = true;
    };
    // 显示
    RankUi.prototype.onShow = function () {
        _super.prototype.onShow.call(this);
        this._dataList1 = null;
        this._res.txt_name.text = qpq.data.PlayerData.s_self.m_name;
        this._res.icon_head1.skin = qpq.data.PlayerData.s_self.m_headUrl;
        this.onTabChange();
        // playSound_qipai("open");
    };
    // 隐藏
    RankUi.prototype.onClose = function () {
        _super.prototype.onClose.call(this);
    };
    // 协议
    RankUi.prototype.reciveNetMsg = function (msgId, data) {
        if (msgId == 0x0F28) // 数据库排行
         {
            var arr;
            if (data.type == 1) {
                arr = this._dataList1 = []; // 富豪榜
            }
            for (var i = 0; i < data.list.length; i++) {
                var obj = JSON.parse(data.list[i].json_str);
                var pd = new qpq.data.PlayerData();
                pd.m_id = obj.char_id;
                pd.m_headUrl = obj.icon;
                pd.m_pId = obj.pid;
                pd.vipLevel = obj.vip_lv;
                pd.m_level = obj.level;
                pd.m_name = obj.nick;
                pd.m_name = utils.tools.getBanWord(pd.m_name);
                if (data.type == 3) {
                    pd.m_money = obj.extra_data1;
                }
                else {
                    pd.m_money = obj.order_score;
                }
                arr.push(pd);
            }
            this.update();
            g_uiMgr.closeMiniLoading();
        }
    };
    // 更新
    RankUi.prototype.update = function () {
        this._list.dataSource = this._dataList1;
        this.updateMyRank(this._dataList1);
        this._res['txt_txt'].visible = this._list.dataSource.length == 0;
    };
    // 更新榜单
    RankUi.prototype.updateMyRank = function (arr) {
        var myOrder = -1;
        for (var i = 0; i < arr.length; i++) {
            if (arr[i].m_pId == qpq.data.PlayerData.s_self.m_pId) {
                myOrder = i + 1;
                break;
            }
        }
        if (myOrder == -1) {
            this._self_rank_icon.visible = false;
            this._self_rank_txt.visible = true;
            this._self_rank_txt.text = "榜上无名";
        }
        else {
            if (myOrder <= 3) {
                this._self_rank_icon.visible = true;
                this._self_rank_icon.skin = "window/icon_rank" + myOrder + ".png";
                this._self_rank_txt.visible = false;
            }
            else {
                this._self_rank_icon.visible = false;
                this._self_rank_txt.visible = true;
                this._self_rank_txt.text = myOrder + "";
            }
        }
    };
    // 排行榜单数据
    RankUi.prototype.updateItem = function (box, index) {
        var pd = this._list.dataSource[index]; // 玩家数据
        var icon = getChildByName(box, 'img_rankicon'); // 奖牌
        var head = getChildByName(box, 'b_head.icon_head'); // 头像
        var name_txt = getChildByName(box, 'txt_1'); // 昵称
        var value_txt = getChildByName(box, 'txt_5'); // 金币
        var rank_txt = getChildByName(box, 'txt_4'); // 排名
        var btn = getChildByName(box, 'btn_chakan'); // 查看 
        // bg.skin = index == 0 ? "window/window_6.png":"window/window_7.png";
        if (index >= 3) {
            icon.visible = false;
            rank_txt.visible = true;
            rank_txt.text = (index + 1) + "";
        }
        else {
            icon.visible = true;
            rank_txt.visible = false;
            icon.skin = "window/icon_rank" + (index + 1) + ".png";
        }
        if (pd.m_headUrl) {
            head.skin = pd.m_headUrl;
        }
        else {
            head.skin = "comp/icon_player.png";
        }
        value_txt.text = utils.tools.getMoneyDes(pd.m_money) + "";
        name_txt.text = pd.m_name;
        btn.off(Laya.Event.CLICK, this, this.onClickZhan);
        btn.on(Laya.Event.CLICK, this, this.onClickZhan, [box, pd]);
    };
    // 个人详细信息
    RankUi.prototype.onClickZhan = function (box, pd, evt) {
        // playButtonSound();
        evt.stopPropagation();
        g_signal.dispatch('showUserInfoUi', pd);
    };
    // 换榜
    RankUi.prototype.onTabChange = function (evt) {
        // playButtonSound();
        if (this._dataList1 == null) {
            g_uiMgr.showMiniLoading();
            sendNetMsg(0x0F28, 1);
            return;
        }
        this.update();
    };
    return RankUi;
}(gamelib.core.Ui_NetHandle));
exports.default = RankUi;

},{}],7:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Global_1 = require("./Global");
var SignIn = /** @class */ (function (_super) {
    __extends(SignIn, _super);
    function SignIn() {
        return _super.call(this, 'qpq/Art_Sign') || this;
        // super();
    }
    // 初始化
    SignIn.prototype.init = function () {
        _super.prototype.init.call(this);
        this.addBtnToListener("btn_lq"); // 马上领取
        this._items = [];
        for (var i = 1; i <= 7; i++) {
            this._items.push(this._res['ui_item_' + i]);
            this._res['ui_item_' + i].visible = false;
        }
        this._noticeOther = true;
    };
    // 显示
    SignIn.prototype.onShow = function () {
        _super.prototype.onShow.call(this);
        this._data = Global_1.g_signInfo;
        if (this._data == null) {
            // sendNetMsg(0x0F1A);
        }
        else {
            this.setSiginData();
        }
        for (var i = 0; i < this._items.length; i++) {
            var item = this._items[i];
            item['btn_bq'].on(Laya.Event.CLICK, this, this.onClickBQ, [i + 1]);
        }
        // playSound_qipai("open");
    };
    // 隐藏
    SignIn.prototype.onClose = function () {
        _super.prototype.onClose.call(this);
    };
    SignIn.prototype.onClickQD = function (index, evt) {
        // playButtonSound();
        sendNetMsg(0x0F1B, 1, index);
        evt.currentTarget['disabled'] = true;
    };
    SignIn.prototype.onClickBQ = function (index, evt) {
        // playButtonSound();
        sendNetMsg(0x0F1B, 2, index);
        evt.currentTarget['disabled'] = true;
    };
    // 协议
    SignIn.prototype.reciveNetMsg = function (msgId, data) {
        switch (msgId) {
            case 0x0F1A: // 公共配置签到列表
                this._data = data;
                this.setSiginData();
                break;
            case 0x0F1B: // 公共配置签到
                if (data.result == 0) {
                    g_uiMgr.showTip("签到失败");
                    return;
                }
                this.setSiginData();
                break;
        }
    };
    // 按钮
    SignIn.prototype.onClickObjects = function (evt) {
        playButtonSound();
        switch (evt.currentTarget.name) {
            case "btn_lq": // 马上领取
                // playButtonSound();
                // sendNetMsg(0x0F1B,1,this._index);
                // evt.currentTarget['disabled'] = true;
                break;
        }
    };
    SignIn.prototype.setSiginData = function () {
        if (this._data == null) {
            return;
        }
        this._index = -1;
        var day = ['第一天', '第二天', '第三天', '第四天', '第五天', '第六天', '第七天'];
        for (var i = 0; i < this._items.length; i++) {
            var item = this._items[i];
            var data = this._data.list[i];
            if (data == null) {
                item.visible = false;
                continue;
            }
            var num = data.awards[0].num;
            item['txt_1'].text = num + ""; //	奖励
            item['txt_2'].text = day[i];
            item['img_money'].skin = "hall/goods_" + (i + 1) + ".png";
            item.disabled = data.statue == 4; //未到时
            item.alpha = 1;
            item.visible = true;
            switch (data.statue) {
                case 0: //时间未到
                case 4: //已过期	
                    item['btn_bq'].visible = false;
                    item['img_yqd'].visible = false;
                    break;
                case 1: //可以签到	
                    this._index = i + 1;
                    item['btn_bq'].visible = false;
                    item['img_yqd'].visible = false;
                    break;
                case 2: //已签到				
                    item['btn_bq'].visible = false;
                    item['img_yqd'].visible = true;
                    item.alpha = 0.5;
                    break;
                case 3: //可补签
                    item['btn_bq'].visible = true;
                    item['img_yqd'].visible = false;
                    break;
                default:
                    // code...
                    break;
            }
            num = 0;
            var vipInfo = Global_1.getVipInfo(gamelib.data.UserInfo.s_self.vipLevel);
            if (vipInfo.sign_add[0]) {
                num = num + vipInfo.sign_add[0].num;
            }
            item['txt_3'].text = "vip加成:+" + num;
            if (num == 0) {
                item['txt_3'].text = "";
            }
        }
        this._res['btn_lq'].disabled = this._index == -1;
    };
    return SignIn;
}(gamelib.core.Ui_NetHandle));
exports.default = SignIn;

},{"./Global":3}],8:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var SubHall1 = /** @class */ (function (_super) {
    __extends(SubHall1, _super);
    function SubHall1() {
        return _super.call(this, "qpq/Art_SubHall1") || this;
    }
    SubHall1.prototype.init = function () {
        for (var i = 1; i <= 4; i++) {
            this.addBtnToListener('btn_entry' + i);
        }
    };
    SubHall1.prototype.setData = function (params) {
        this._config = params;
        for (var i = 0; i < 4; i++) {
            var rd = this._config.rooms[i];
            var item = this._res['btn_entry' + (i + 1)];
            var _base = item['txt_2'];
            var _ticket = item['txt_4'];
            _base.text = rd.base;
            _ticket.text = "入场:" + utils.tools.getMoneyDes(rd.ticket);
        }
    };
    SubHall1.prototype.onClickCloseBtn = function (evt) {
        evt.stopPropagation();
        // playSound_qipai("back");
        this.isClosedByCloseBtn = true;
        this.close();
    };
    // 按钮
    SubHall1.prototype.onClickObjects = function (evt) {
        playButtonSound();
        switch (evt.currentTarget.name) {
            case "btn_help": // 帮助
                g_signal.dispatch('showHelpUiInGame', 0);
                console.log("帮助");
                break;
            case "btn_shop2": // 打开商城
                g_uiMgr.openShop();
                break;
            default:
                if (evt.currentTarget.name.indexOf('btn_entry') == -1)
                    return;
                var index = parseInt(evt.currentTarget.name.charAt(evt.currentTarget.name.length - 1));
                qpq.enterRoom(this._config.gz_id, this._config.rooms[index - 1]);
                this.close();
                break;
        }
    };
    return SubHall1;
}(gamelib.core.BaseUi));
exports.default = SubHall1;

},{}],9:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**This class is automatically generated by LayaAirIDE, please do not make any modifications. */
var View = Laya.View;
var Dialog = Laya.Dialog;
var ui;
(function (ui) {
    var qpq;
    (function (qpq) {
        var Art_ComTipsUI = /** @class */ (function (_super) {
            __extends(Art_ComTipsUI, _super);
            function Art_ComTipsUI() {
                return _super.call(this) || this;
            }
            Art_ComTipsUI.prototype.createChildren = function () {
                _super.prototype.createChildren.call(this);
                this.loadScene("qpq/Art_ComTips");
            };
            return Art_ComTipsUI;
        }(View));
        qpq.Art_ComTipsUI = Art_ComTipsUI;
        var Art_CustomTipsUI = /** @class */ (function (_super) {
            __extends(Art_CustomTipsUI, _super);
            function Art_CustomTipsUI() {
                return _super.call(this) || this;
            }
            Art_CustomTipsUI.prototype.createChildren = function () {
                _super.prototype.createChildren.call(this);
                this.loadScene("qpq/Art_CustomTips");
            };
            return Art_CustomTipsUI;
        }(Dialog));
        qpq.Art_CustomTipsUI = Art_CustomTipsUI;
        var Art_CustomTips1UI = /** @class */ (function (_super) {
            __extends(Art_CustomTips1UI, _super);
            function Art_CustomTips1UI() {
                return _super.call(this) || this;
            }
            Art_CustomTips1UI.prototype.createChildren = function () {
                _super.prototype.createChildren.call(this);
                this.loadScene("qpq/Art_CustomTips1");
            };
            return Art_CustomTips1UI;
        }(Dialog));
        qpq.Art_CustomTips1UI = Art_CustomTips1UI;
        var Art_GameBRNNUI = /** @class */ (function (_super) {
            __extends(Art_GameBRNNUI, _super);
            function Art_GameBRNNUI() {
                return _super.call(this) || this;
            }
            Art_GameBRNNUI.prototype.createChildren = function () {
                _super.prototype.createChildren.call(this);
                this.loadScene("qpq/Art_GameBRNN");
            };
            return Art_GameBRNNUI;
        }(View));
        qpq.Art_GameBRNNUI = Art_GameBRNNUI;
        var Art_GameXZ_SRUI = /** @class */ (function (_super) {
            __extends(Art_GameXZ_SRUI, _super);
            function Art_GameXZ_SRUI() {
                return _super.call(this) || this;
            }
            Art_GameXZ_SRUI.prototype.createChildren = function () {
                _super.prototype.createChildren.call(this);
                this.loadScene("qpq/Art_GameXZ_SR");
            };
            return Art_GameXZ_SRUI;
        }(View));
        qpq.Art_GameXZ_SRUI = Art_GameXZ_SRUI;
        var Art_HallUI = /** @class */ (function (_super) {
            __extends(Art_HallUI, _super);
            function Art_HallUI() {
                return _super.call(this) || this;
            }
            Art_HallUI.prototype.createChildren = function () {
                _super.prototype.createChildren.call(this);
                this.loadScene("qpq/Art_Hall");
            };
            return Art_HallUI;
        }(View));
        qpq.Art_HallUI = Art_HallUI;
        var Art_JieSuanUI = /** @class */ (function (_super) {
            __extends(Art_JieSuanUI, _super);
            function Art_JieSuanUI() {
                return _super.call(this) || this;
            }
            Art_JieSuanUI.prototype.createChildren = function () {
                _super.prototype.createChildren.call(this);
                this.loadScene("qpq/Art_JieSuan");
            };
            return Art_JieSuanUI;
        }(Dialog));
        qpq.Art_JieSuanUI = Art_JieSuanUI;
        var Art_JiesuanltemUI = /** @class */ (function (_super) {
            __extends(Art_JiesuanltemUI, _super);
            function Art_JiesuanltemUI() {
                return _super.call(this) || this;
            }
            Art_JiesuanltemUI.prototype.createChildren = function () {
                _super.prototype.createChildren.call(this);
                this.loadScene("qpq/Art_Jiesuanltem");
            };
            return Art_JiesuanltemUI;
        }(Dialog));
        qpq.Art_JiesuanltemUI = Art_JiesuanltemUI;
        var Art_KeyboardUI = /** @class */ (function (_super) {
            __extends(Art_KeyboardUI, _super);
            function Art_KeyboardUI() {
                return _super.call(this) || this;
            }
            Art_KeyboardUI.prototype.createChildren = function () {
                _super.prototype.createChildren.call(this);
                this.loadScene("qpq/Art_Keyboard");
            };
            return Art_KeyboardUI;
        }(Dialog));
        qpq.Art_KeyboardUI = Art_KeyboardUI;
        var Art_Keyboard1UI = /** @class */ (function (_super) {
            __extends(Art_Keyboard1UI, _super);
            function Art_Keyboard1UI() {
                return _super.call(this) || this;
            }
            Art_Keyboard1UI.prototype.createChildren = function () {
                _super.prototype.createChildren.call(this);
                this.loadScene("qpq/Art_Keyboard1");
            };
            return Art_Keyboard1UI;
        }(Dialog));
        qpq.Art_Keyboard1UI = Art_Keyboard1UI;
        var Art_Keyboard2UI = /** @class */ (function (_super) {
            __extends(Art_Keyboard2UI, _super);
            function Art_Keyboard2UI() {
                return _super.call(this) || this;
            }
            Art_Keyboard2UI.prototype.createChildren = function () {
                _super.prototype.createChildren.call(this);
                this.loadScene("qpq/Art_Keyboard2");
            };
            return Art_Keyboard2UI;
        }(Dialog));
        qpq.Art_Keyboard2UI = Art_Keyboard2UI;
        var Art_Keyboard3UI = /** @class */ (function (_super) {
            __extends(Art_Keyboard3UI, _super);
            function Art_Keyboard3UI() {
                return _super.call(this) || this;
            }
            Art_Keyboard3UI.prototype.createChildren = function () {
                _super.prototype.createChildren.call(this);
                this.loadScene("qpq/Art_Keyboard3");
            };
            return Art_Keyboard3UI;
        }(Dialog));
        qpq.Art_Keyboard3UI = Art_Keyboard3UI;
        var Art_LoadingUI = /** @class */ (function (_super) {
            __extends(Art_LoadingUI, _super);
            function Art_LoadingUI() {
                return _super.call(this) || this;
            }
            Art_LoadingUI.prototype.createChildren = function () {
                _super.prototype.createChildren.call(this);
                this.loadScene("qpq/Art_Loading");
            };
            return Art_LoadingUI;
        }(View));
        qpq.Art_LoadingUI = Art_LoadingUI;
        var Art_MailUI = /** @class */ (function (_super) {
            __extends(Art_MailUI, _super);
            function Art_MailUI() {
                return _super.call(this) || this;
            }
            Art_MailUI.prototype.createChildren = function () {
                _super.prototype.createChildren.call(this);
                this.loadScene("qpq/Art_Mail");
            };
            return Art_MailUI;
        }(Dialog));
        qpq.Art_MailUI = Art_MailUI;
        var Art_MailTipsUI = /** @class */ (function (_super) {
            __extends(Art_MailTipsUI, _super);
            function Art_MailTipsUI() {
                return _super.call(this) || this;
            }
            Art_MailTipsUI.prototype.createChildren = function () {
                _super.prototype.createChildren.call(this);
                this.loadScene("qpq/Art_MailTips");
            };
            return Art_MailTipsUI;
        }(Dialog));
        qpq.Art_MailTipsUI = Art_MailTipsUI;
        var Art_NoticeUI = /** @class */ (function (_super) {
            __extends(Art_NoticeUI, _super);
            function Art_NoticeUI() {
                return _super.call(this) || this;
            }
            Art_NoticeUI.prototype.createChildren = function () {
                _super.prototype.createChildren.call(this);
                this.loadScene("qpq/Art_Notice");
            };
            return Art_NoticeUI;
        }(Dialog));
        qpq.Art_NoticeUI = Art_NoticeUI;
        var Art_PlayerinfoUI = /** @class */ (function (_super) {
            __extends(Art_PlayerinfoUI, _super);
            function Art_PlayerinfoUI() {
                return _super.call(this) || this;
            }
            Art_PlayerinfoUI.prototype.createChildren = function () {
                _super.prototype.createChildren.call(this);
                this.loadScene("qpq/Art_Playerinfo");
            };
            return Art_PlayerinfoUI;
        }(Dialog));
        qpq.Art_PlayerinfoUI = Art_PlayerinfoUI;
        var Art_Playerinfo_1UI = /** @class */ (function (_super) {
            __extends(Art_Playerinfo_1UI, _super);
            function Art_Playerinfo_1UI() {
                return _super.call(this) || this;
            }
            Art_Playerinfo_1UI.prototype.createChildren = function () {
                _super.prototype.createChildren.call(this);
                this.loadScene("qpq/Art_Playerinfo_1");
            };
            return Art_Playerinfo_1UI;
        }(Dialog));
        qpq.Art_Playerinfo_1UI = Art_Playerinfo_1UI;
        var Art_RankUI = /** @class */ (function (_super) {
            __extends(Art_RankUI, _super);
            function Art_RankUI() {
                return _super.call(this) || this;
            }
            Art_RankUI.prototype.createChildren = function () {
                _super.prototype.createChildren.call(this);
                this.loadScene("qpq/Art_Rank");
            };
            return Art_RankUI;
        }(Dialog));
        qpq.Art_RankUI = Art_RankUI;
        var Art_RecordUI = /** @class */ (function (_super) {
            __extends(Art_RecordUI, _super);
            function Art_RecordUI() {
                return _super.call(this) || this;
            }
            Art_RecordUI.prototype.createChildren = function () {
                _super.prototype.createChildren.call(this);
                this.loadScene("qpq/Art_Record");
            };
            return Art_RecordUI;
        }(Dialog));
        qpq.Art_RecordUI = Art_RecordUI;
        var Art_Record1UI = /** @class */ (function (_super) {
            __extends(Art_Record1UI, _super);
            function Art_Record1UI() {
                return _super.call(this) || this;
            }
            Art_Record1UI.prototype.createChildren = function () {
                _super.prototype.createChildren.call(this);
                this.loadScene("qpq/Art_Record1");
            };
            return Art_Record1UI;
        }(Dialog));
        qpq.Art_Record1UI = Art_Record1UI;
        var Art_RecordItemUI = /** @class */ (function (_super) {
            __extends(Art_RecordItemUI, _super);
            function Art_RecordItemUI() {
                return _super.call(this) || this;
            }
            Art_RecordItemUI.prototype.createChildren = function () {
                _super.prototype.createChildren.call(this);
                this.loadScene("qpq/Art_RecordItem");
            };
            return Art_RecordItemUI;
        }(Dialog));
        qpq.Art_RecordItemUI = Art_RecordItemUI;
        var Art_RoomInfoUI = /** @class */ (function (_super) {
            __extends(Art_RoomInfoUI, _super);
            function Art_RoomInfoUI() {
                return _super.call(this) || this;
            }
            Art_RoomInfoUI.prototype.createChildren = function () {
                _super.prototype.createChildren.call(this);
                this.loadScene("qpq/Art_RoomInfo");
            };
            return Art_RoomInfoUI;
        }(Dialog));
        qpq.Art_RoomInfoUI = Art_RoomInfoUI;
        var Art_ShareUI = /** @class */ (function (_super) {
            __extends(Art_ShareUI, _super);
            function Art_ShareUI() {
                return _super.call(this) || this;
            }
            Art_ShareUI.prototype.createChildren = function () {
                _super.prototype.createChildren.call(this);
                this.loadScene("qpq/Art_Share");
            };
            return Art_ShareUI;
        }(Dialog));
        qpq.Art_ShareUI = Art_ShareUI;
        var Art_ShopTipsUI = /** @class */ (function (_super) {
            __extends(Art_ShopTipsUI, _super);
            function Art_ShopTipsUI() {
                return _super.call(this) || this;
            }
            Art_ShopTipsUI.prototype.createChildren = function () {
                _super.prototype.createChildren.call(this);
                this.loadScene("qpq/Art_ShopTips");
            };
            return Art_ShopTipsUI;
        }(Dialog));
        qpq.Art_ShopTipsUI = Art_ShopTipsUI;
        var Art_SignUI = /** @class */ (function (_super) {
            __extends(Art_SignUI, _super);
            function Art_SignUI() {
                return _super.call(this) || this;
            }
            Art_SignUI.prototype.createChildren = function () {
                _super.prototype.createChildren.call(this);
                this.loadScene("qpq/Art_Sign");
            };
            return Art_SignUI;
        }(Dialog));
        qpq.Art_SignUI = Art_SignUI;
        var Art_Signltem1UI = /** @class */ (function (_super) {
            __extends(Art_Signltem1UI, _super);
            function Art_Signltem1UI() {
                return _super.call(this) || this;
            }
            Art_Signltem1UI.prototype.createChildren = function () {
                _super.prototype.createChildren.call(this);
                this.loadScene("qpq/Art_Signltem1");
            };
            return Art_Signltem1UI;
        }(Dialog));
        qpq.Art_Signltem1UI = Art_Signltem1UI;
        var Art_SubEntry_1UI = /** @class */ (function (_super) {
            __extends(Art_SubEntry_1UI, _super);
            function Art_SubEntry_1UI() {
                return _super.call(this) || this;
            }
            Art_SubEntry_1UI.prototype.createChildren = function () {
                _super.prototype.createChildren.call(this);
                this.loadScene("qpq/Art_SubEntry_1");
            };
            return Art_SubEntry_1UI;
        }(View));
        qpq.Art_SubEntry_1UI = Art_SubEntry_1UI;
        var Art_SubEntry_2UI = /** @class */ (function (_super) {
            __extends(Art_SubEntry_2UI, _super);
            function Art_SubEntry_2UI() {
                return _super.call(this) || this;
            }
            Art_SubEntry_2UI.prototype.createChildren = function () {
                _super.prototype.createChildren.call(this);
                this.loadScene("qpq/Art_SubEntry_2");
            };
            return Art_SubEntry_2UI;
        }(View));
        qpq.Art_SubEntry_2UI = Art_SubEntry_2UI;
        var Art_SubEntry_3UI = /** @class */ (function (_super) {
            __extends(Art_SubEntry_3UI, _super);
            function Art_SubEntry_3UI() {
                return _super.call(this) || this;
            }
            Art_SubEntry_3UI.prototype.createChildren = function () {
                _super.prototype.createChildren.call(this);
                this.loadScene("qpq/Art_SubEntry_3");
            };
            return Art_SubEntry_3UI;
        }(View));
        qpq.Art_SubEntry_3UI = Art_SubEntry_3UI;
        var Art_SubEntry_4UI = /** @class */ (function (_super) {
            __extends(Art_SubEntry_4UI, _super);
            function Art_SubEntry_4UI() {
                return _super.call(this) || this;
            }
            Art_SubEntry_4UI.prototype.createChildren = function () {
                _super.prototype.createChildren.call(this);
                this.loadScene("qpq/Art_SubEntry_4");
            };
            return Art_SubEntry_4UI;
        }(View));
        qpq.Art_SubEntry_4UI = Art_SubEntry_4UI;
        var Art_SubHall1UI = /** @class */ (function (_super) {
            __extends(Art_SubHall1UI, _super);
            function Art_SubHall1UI() {
                return _super.call(this) || this;
            }
            Art_SubHall1UI.prototype.createChildren = function () {
                _super.prototype.createChildren.call(this);
                this.loadScene("qpq/Art_SubHall1");
            };
            return Art_SubHall1UI;
        }(Dialog));
        qpq.Art_SubHall1UI = Art_SubHall1UI;
        var Art_Tips_ToupiaoUI = /** @class */ (function (_super) {
            __extends(Art_Tips_ToupiaoUI, _super);
            function Art_Tips_ToupiaoUI() {
                return _super.call(this) || this;
            }
            Art_Tips_ToupiaoUI.prototype.createChildren = function () {
                _super.prototype.createChildren.call(this);
                this.loadScene("qpq/Art_Tips_Toupiao");
            };
            return Art_Tips_ToupiaoUI;
        }(Dialog));
        qpq.Art_Tips_ToupiaoUI = Art_Tips_ToupiaoUI;
        var Art_ZhanjiUI = /** @class */ (function (_super) {
            __extends(Art_ZhanjiUI, _super);
            function Art_ZhanjiUI() {
                return _super.call(this) || this;
            }
            Art_ZhanjiUI.prototype.createChildren = function () {
                _super.prototype.createChildren.call(this);
                this.loadScene("qpq/Art_Zhanji");
            };
            return Art_ZhanjiUI;
        }(Dialog));
        qpq.Art_ZhanjiUI = Art_ZhanjiUI;
        var Art_ZhuanQuanUI = /** @class */ (function (_super) {
            __extends(Art_ZhuanQuanUI, _super);
            function Art_ZhuanQuanUI() {
                return _super.call(this) || this;
            }
            Art_ZhuanQuanUI.prototype.createChildren = function () {
                _super.prototype.createChildren.call(this);
                this.loadScene("qpq/Art_ZhuanQuan");
            };
            return Art_ZhuanQuanUI;
        }(View));
        qpq.Art_ZhuanQuanUI = Art_ZhuanQuanUI;
    })(qpq = ui.qpq || (ui.qpq = {}));
})(ui = exports.ui || (exports.ui = {}));

},{}]},{},[1]);
