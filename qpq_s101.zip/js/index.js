﻿/**
 * 设置LayaNative屏幕方向，可设置以下值
 * landscape           横屏
 * portrait            竖屏
 * sensor_landscape    横屏(双方向)
 * sensor_portrait     竖屏(双方向)
 */
window.screenOrientation = "sensor_landscape";
function loadLib(url) {
	var script = document.createElement("script");
	script.async = false;
	script.src = url;
	document.body.appendChild(script);
}
var path = "";
if(urlParam && urlParam['game_path'])
	path = urlParam['game_path'];

//-----libs-begin-----
loadLib(path + "libs/laya.core.js");
loadLib(path + "libs/laya.webgl.js");
loadLib(path + "libs/laya.ui.js");
//-----libs-end-------
loadLib(path + "pflibs/startup.js");
loadLib(path + "libs/gamelib.js")
loadLib(path + "libs/qpqlib.js")
loadLib(path + "js/qpq/main.js");
